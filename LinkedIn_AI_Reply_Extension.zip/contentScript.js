
document.addEventListener('focusin', (event) => {
  if (event.target.tagName === 'TEXTAREA') {
    // Add AI icon when message field is focused
    console.log('Message input focused');
  }
});
