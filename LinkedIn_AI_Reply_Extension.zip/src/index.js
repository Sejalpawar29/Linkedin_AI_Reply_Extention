
import React, { useState } from 'react';
import ReactDOM from 'react-dom';

function App() {
  const [inputText, setInputText] = useState('');
  const [generatedText, setGeneratedText] = useState('');

  const handleGenerateClick = () => {
    setGeneratedText('Thank you for the opportunity! If you have any more questions...');
  };

  const handleInsertClick = () => {
    const messageField = document.querySelector('textarea');
    if (messageField) {
      messageField.value = generatedText;
    }
  };

  return (
    <div>
      <input
        type="text"
        value={inputText}
        onChange={(e) => setInputText(e.target.value)}
        placeholder="Enter command"
      />
      <button onClick={handleGenerateClick}>Generate</button>
      {generatedText && <p>{generatedText}</p>}
      <button onClick={handleInsertClick}>Insert</button>
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById('app'));
